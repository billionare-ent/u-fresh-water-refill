<?php
// Copy this file to config/sms.php and insert your Africa's Talking credentials.
// Keep sms.php private; never upload it to a public repository.
return [
    'username' => 'sandbox', // Replace with your approved live username.
    'api_key' => 'PASTE_YOUR_API_KEY_HERE',
    'sender_id' => '' // Optional: only use a sender ID approved by your provider.
];
