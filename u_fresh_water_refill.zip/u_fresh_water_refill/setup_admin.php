<?php
require_once __DIR__.'/config/database.php';
require_once __DIR__.'/includes/functions.php';
$count = (int)$conn->query("SELECT COUNT(*) AS n FROM admins")->fetch_assoc()['n'];
$message = '';
if ($_SERVER['REQUEST_METHOD']==='POST' && $count===0) {
 verify_csrf();
 $name=trim($_POST['full_name']??''); $username=trim($_POST['username']??''); $password=$_POST['password']??'';
 if($name===''||$username===''||strlen($password)<10) $message='Enter a name, username and password of at least 10 characters.';
 else {
  $hash=password_hash($password,PASSWORD_DEFAULT);
  $stmt=$conn->prepare("INSERT INTO admins(full_name,username,password_hash) VALUES(?,?,?)");
  $stmt->bind_param('sss',$name,$username,$hash);$stmt->execute();
  $message='Administrator created. Delete setup_admin.php now, then sign in.';
  $count=1;
 }
}
$page_title='Initial Admin Setup';$asset_prefix='';require __DIR__.'/includes/header.php';
?>
<div class="login-box panel"><h1>Initial admin setup</h1>
<?php if($message): ?><div class="alert"><?=e($message)?></div><?php endif;?>
<?php if($count>0): ?><p>An administrator account already exists. For security, remove <strong>setup_admin.php</strong> from your server.</p><a class="btn" href="admin/login.php">Go to admin login</a>
<?php else: ?><p class="muted">Create the first administrator account. Use a strong password.</p>
<form method="post"><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>">
<div class="field"><label>Full name</label><input name="full_name" required></div><br>
<div class="field"><label>Username</label><input name="username" required></div><br>
<div class="field"><label>Password (minimum 10 characters)</label><input type="password" name="password" minlength="10" required></div>
<div class="actions"><button class="btn">Create administrator</button></div></form><?php endif;?></div>
<?php require __DIR__.'/includes/footer.php';?>
