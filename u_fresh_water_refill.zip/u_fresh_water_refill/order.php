<?php
require_once 'config/database.php';require_once 'includes/functions.php';
$products=$conn->query("SELECT id,name,unit,price FROM products WHERE active=1 ORDER BY name");
$selected=(int)($_GET['product']??0);$message='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 verify_csrf();
 $name=trim($_POST['full_name']??'');$phone=trim($_POST['phone']??'');$email=trim($_POST['email']??'');$address=trim($_POST['address']??'');
 $pid=(int)($_POST['product_id']??0);$qty=(int)($_POST['quantity']??1);$delivery=$_POST['delivery_type']??'Pickup';$notes=trim($_POST['notes']??'');
 if($name===''||!valid_phone($phone)||$qty<1||$qty>500||!in_array($delivery,['Pickup','Delivery'],true)) $message='Please check your name, phone number and quantity.';
 else {
  $stmt=$conn->prepare("SELECT name,price FROM products WHERE id=? AND active=1");$stmt->bind_param('i',$pid);$stmt->execute();$p=$stmt->get_result()->fetch_assoc();
  if(!$p)$message='Please select an available product.';
  else{
   $conn->begin_transaction();
   try{
    $c=$conn->prepare("INSERT INTO customers(full_name,phone,email,address) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE full_name=VALUES(full_name),email=VALUES(email),address=VALUES(address)");
    $c->bind_param('ssss',$name,$phone,$email,$address);$c->execute();
    $cs=$conn->prepare("SELECT id FROM customers WHERE phone=?");$cs->bind_param('s',$phone);$cs->execute();$cid=(int)$cs->get_result()->fetch_assoc()['id'];
    $total=(float)$p['price']*$qty;
    $o=$conn->prepare("INSERT INTO orders(customer_id,delivery_type,delivery_address,notes,total) VALUES(?,?,?,?,?)");
    $o->bind_param('isssd',$cid,$delivery,$address,$notes,$total);$o->execute();$oid=$conn->insert_id;
    $it=$conn->prepare("INSERT INTO order_items(order_id,product_id,product_name,quantity,unit_price,line_total) VALUES(?,?,?,?,?,?)");
    $it->bind_param('iisidd',$oid,$pid,$p['name'],$qty,$p['price'],$total);$it->execute();
    $conn->commit();$message='Thank you! Your order #'.$oid.' has been received. Total: '.money($total);
   }catch(Throwable $e){$conn->rollback();$message='We could not save your order. Please try again.';}
  }
 }
}
$page_title='Place an Order';require 'includes/header.php';
?>
<div class="section-head"><div><h1>Place an order</h1><p class="muted">Complete the form and U-Fresh will receive your order.</p></div></div>
<?php if($message):?><div class="alert"><?=e($message)?></div><?php endif;?>
<div class="panel"><form method="post"><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>">
<div class="form-grid">
<div class="field"><label>Full name *</label><input name="full_name" required></div>
<div class="field"><label>Phone number *</label><input name="phone" placeholder="07XXXXXXXX" required></div>
<div class="field"><label>Email (optional)</label><input type="email" name="email"></div>
<div class="field"><label>Product *</label><select name="product_id" id="product-select" required><option value="">Choose product</option><?php $products->data_seek(0);while($p=$products->fetch_assoc()):?><option value="<?=$p['id']?>" data-price="<?=$p['price']?>" <?=$selected===(int)$p['id']?'selected':''?>><?=e($p['name'])?> — <?=money($p['price'])?> / <?=e($p['unit'])?></option><?php endwhile;?></select></div>
<div class="field"><label>Quantity *</label><input type="number" name="quantity" id="quantity" min="1" max="500" value="1" required></div>
<div class="field"><label>Collection / delivery</label><select name="delivery_type"><option>Pickup</option><option>Delivery</option></select></div>
<div class="field full"><label>Delivery address (if applicable)</label><input name="address"></div>
<div class="field full"><label>Additional notes</label><textarea name="notes"></textarea></div>
</div><div class="actions"><button class="btn">Submit order</button><strong>Estimated total: <span id="order-total">KSh 0.00</span></strong></div></form></div>
<script>
document.addEventListener('DOMContentLoaded',()=>{const s=document.querySelector('#product-select'),q=document.querySelector('#quantity'),o=document.querySelector('#order-total');function calc(){const p=Number(s.selectedOptions[0]?.dataset.price||0);o.textContent='KSh '+(p*Number(q.value||1)).toFixed(2)}s.addEventListener('change',calc);q.addEventListener('input',calc);calc();});
</script>
<?php require 'includes/footer.php';?>
