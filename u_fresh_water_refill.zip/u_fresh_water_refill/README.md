# U-Fresh Water Refill website

A starter PHP + MySQLi (no PDO) website and admin system.

## Included
- Public home page showing active products and prices from MySQL
- Customer order form
- Admin login with password hashing and session regeneration
- Product management: add, edit, change price, activate/deactivate and delete
- Customer list and marketing SMS consent field
- Order list and status updates
- Basic sales reports
- Bulk SMS integration scaffold for Africa's Talking

## Requirements
- PHP 8.1+ (recommended)
- MySQL 5.7+ / MariaDB
- Apache (XAMPP, WAMP, Laragon or hosting)
- PHP extensions: mysqli, curl, mbstring
- HTTPS for a live website

## Local installation using XAMPP
1. Extract `u_fresh_water_refill.zip`.
2. Copy the `u_fresh_water_refill` folder into `C:\xampp\htdocs\`.
3. Start Apache and MySQL from XAMPP Control Panel.
4. Open `http://localhost/phpmyadmin`.
5. Import `database/u_fresh_water_refill.sql`.
6. Check `config/database.php`. The default XAMPP values are `root`, blank password and database `u_fresh_water_refill`.
7. Visit `http://localhost/u_fresh_water_refill/setup_admin.php`.
8. Create your first admin account with a strong password (10+ characters).
9. **Delete `setup_admin.php` from the project folder after creating the admin.**
10. Open `http://localhost/u_fresh_water_refill/`.

Admin login: `http://localhost/u_fresh_water_refill/admin/login.php`

## Change product prices
Sign in as admin → Products → Edit → update the price → Save product.
The public website and new orders will use the latest saved price. Existing orders retain the price recorded at the time they were placed.

## Configure bulk SMS
1. Register with Africa's Talking and complete any required account, sender ID and compliance approvals.
2. In the project folder, copy `config/sms.example.php` to `config/sms.php`.
3. Enter your live username and API key in `config/sms.php`. Never share the API key or commit it to public source control.
4. Ensure PHP cURL is enabled and the server can make outbound HTTPS requests.
5. Add customer phone numbers and record marketing consent before sending promotions.
6. Admin → Bulk SMS → compose a message → choose opted-in customers → submit.
7. Test first with the provider's sandbox/test setup and a small number of opted-in test contacts.

The current integration submits a bulk request to the Africa's Talking messaging endpoint and records per-recipient submission logs. A successful HTTP response means the provider accepted the request; it does **not** prove delivery. Check the provider dashboard/callback reports for final delivery status. Configure sender ID approval with the provider. SMS costs and availability depend on the provider account.

## Important before going live
This is a functional starter, not a fully audited production deployment.
- Use HTTPS and strong unique passwords.
- Restrict server access to configuration files; protect `config/sms.php`.
- Add rate limiting, login lockout, audit logs, backups and server monitoring.
- Configure privacy notice, data retention and customer consent/opt-out workflow in line with applicable Kenyan law and provider rules.
- Do not send marketing SMS to people who have not opted in. Add an actual STOP/unsubscribe processing route before marketing at scale.
- Add M-Pesa Daraja integration separately; this project currently records payment data in the database schema but does not process M-Pesa payments.
- Add business phone, physical location, delivery fees and operating hours before publishing.
- The product prices are the initial prices supplied: refill per litre KSh 10; 20L KSh 300; 10L KSh 170; 5L KSh 80. The admin can change or add products.

## Folder map
- `index.php`, `order.php`: public pages
- `admin/`: protected admin pages
- `config/`: database and SMS configuration
- `database/`: SQL schema and initial products
- `assets/`: CSS and JavaScript
- `includes/`: shared PHP helpers and layout
