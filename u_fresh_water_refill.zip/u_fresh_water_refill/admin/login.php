<?php
require_once '../config/database.php';require_once '../includes/functions.php';
if(is_logged_in())redirect('dashboard.php');$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){verify_csrf();$u=trim($_POST['username']??'');$p=$_POST['password']??'';
 $s=$conn->prepare("SELECT id,full_name,password_hash,role FROM admins WHERE username=?");$s->bind_param('s',$u);$s->execute();$a=$s->get_result()->fetch_assoc();
 if($a&&password_verify($p,$a['password_hash'])){session_regenerate_id(true);$_SESSION['admin_id']=$a['id'];$_SESSION['admin_name']=$a['full_name'];$_SESSION['admin_role']=$a['role'];redirect('dashboard.php');}
 $error='Invalid username or password.';
}
$page_title='Admin Login';$asset_prefix='../';require '../includes/header.php';
?>
<div class="login-box panel"><h1>Admin sign in</h1><p class="muted">U-Fresh Water Refill management</p><?php if($error):?><div class="alert error"><?=e($error)?></div><?php endif;?>
<form method="post"><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>"><div class="field"><label>Username</label><input name="username" required autofocus></div><br><div class="field"><label>Password</label><input type="password" name="password" required></div><div class="actions"><button class="btn">Sign in</button></div></form></div>
<?php require '../includes/footer.php';?>
