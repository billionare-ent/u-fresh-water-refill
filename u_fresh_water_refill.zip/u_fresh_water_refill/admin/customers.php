<?php
require_once '../config/database.php';require_once '../includes/functions.php';require_admin();
if($_SERVER['REQUEST_METHOD']==='POST'){verify_csrf();$id=(int)($_POST['id']??0);$consent=isset($_POST['sms_consent'])?1:0;$s=$conn->prepare("UPDATE customers SET sms_consent=? WHERE id=?");$s->bind_param('ii',$consent,$id);$s->execute();flash('success','Customer SMS preference updated.');redirect('customers.php');}
$rows=$conn->query("SELECT * FROM customers ORDER BY created_at DESC");$page_title='Customers';$admin_nav=true;require '../includes/header.php';
?>
<div class="admin-title"><div><h1>Customers</h1><p class="muted">Manage customer records and SMS marketing consent.</p></div></div>
<div class="table-wrap"><table><tr><th>Name</th><th>Phone</th><th>Email</th><th>Address</th><th>Marketing SMS consent</th></tr><?php while($c=$rows->fetch_assoc()):?><tr><td><?=e($c['full_name'])?></td><td><?=e($c['phone'])?></td><td><?=e($c['email'])?></td><td><?=e($c['address'])?></td><td><form method="post"><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>"><input type="hidden" name="id" value="<?=$c['id']?>"><label><input type="checkbox" name="sms_consent" value="1" style="width:auto" <?=$c['sms_consent']?'checked':''?> onchange="this.form.submit()"> Consented</label></form></td></tr><?php endwhile;?></table></div>
<?php require '../includes/footer.php';?>
