<?php
require_once '../config/database.php';require_once '../includes/functions.php';require_admin();
$products=(int)$conn->query("SELECT COUNT(*) n FROM products")->fetch_assoc()['n'];
$customers=(int)$conn->query("SELECT COUNT(*) n FROM customers")->fetch_assoc()['n'];
$orders=(int)$conn->query("SELECT COUNT(*) n FROM orders WHERE DATE(created_at)=CURDATE()")->fetch_assoc()['n'];
$sales=(float)$conn->query("SELECT COALESCE(SUM(total),0) n FROM orders WHERE status<>'Cancelled' AND DATE(created_at)=CURDATE()")->fetch_assoc()['n'];
$recent=$conn->query("SELECT o.id,o.total,o.status,o.created_at,c.full_name FROM orders o JOIN customers c ON c.id=o.customer_id ORDER BY o.id DESC LIMIT 8");
$page_title='Admin Dashboard';$admin_nav=true;require '../includes/header.php';
?>
<div class="admin-title"><div><h1>Dashboard</h1><p class="muted">Welcome, <?=e($_SESSION['admin_name'])?>.</p></div><a class="btn" href="products.php">Manage prices</a></div>
<div class="stats"><div class="card stat"><strong><?=$orders?></strong><span>Orders today</span></div><div class="card stat"><strong><?=money($sales)?></strong><span>Sales today</span></div><div class="card stat"><strong><?=$customers?></strong><span>Customers</span></div><div class="card stat"><strong><?=$products?></strong><span>Products</span></div></div>
<section class="section"><h2>Recent orders</h2><div class="table-wrap"><table><tr><th>Order</th><th>Customer</th><th>Total</th><th>Status</th><th>Date</th></tr><?php while($r=$recent->fetch_assoc()):?><tr><td>#<?=$r['id']?></td><td><?=e($r['full_name'])?></td><td><?=money($r['total'])?></td><td><span class="status <?=in_array($r['status'],['New','Processing'])?'pending':''?>"><?=e($r['status'])?></span></td><td><?=e($r['created_at'])?></td></tr><?php endwhile;?></table></div></section>
<?php require '../includes/footer.php';?>
