<?php
require_once '../config/database.php';require_once '../includes/functions.php';require_admin();
$from=$_GET['from']??date('Y-m-01');$to=$_GET['to']??date('Y-m-d');
$s=$conn->prepare("SELECT COUNT(*) orders_count,COALESCE(SUM(CASE WHEN status<>'Cancelled' THEN total ELSE 0 END),0) sales FROM orders WHERE DATE(created_at) BETWEEN ? AND ?");$s->bind_param('ss',$from,$to);$s->execute();$summary=$s->get_result()->fetch_assoc();
$rows=$conn->prepare("SELECT DATE(created_at) day,COUNT(*) orders_count,SUM(CASE WHEN status<>'Cancelled' THEN total ELSE 0 END) sales FROM orders WHERE DATE(created_at) BETWEEN ? AND ? GROUP BY DATE(created_at) ORDER BY day DESC");$rows->bind_param('ss',$from,$to);$rows->execute();$data=$rows->get_result();
$page_title='Reports';$admin_nav=true;require '../includes/header.php';
?>
<div class="admin-title"><div><h1>Sales reports</h1><p class="muted">Order totals for a selected date range.</p></div></div>
<div class="panel"><form method="get" class="form-grid"><div class="field"><label>From</label><input type="date" name="from" value="<?=e($from)?>"></div><div class="field"><label>To</label><input type="date" name="to" value="<?=e($to)?>"></div><div class="actions"><button class="btn">Filter report</button></div></form></div>
<div class="stats section"><div class="card stat"><strong><?=$summary['orders_count']?></strong><span>Orders</span></div><div class="card stat"><strong><?=money($summary['sales'])?></strong><span>Sales excluding cancelled orders</span></div></div>
<div class="table-wrap"><table><tr><th>Date</th><th>Orders</th><th>Sales</th></tr><?php while($r=$data->fetch_assoc()):?><tr><td><?=e($r['day'])?></td><td><?=$r['orders_count']?></td><td><?=money($r['sales'])?></td></tr><?php endwhile;?></table></div>
<?php require '../includes/footer.php';?>
