<?php
require_once '../config/database.php';require_once '../includes/functions.php';require_admin();
$config_file=__DIR__.'/../config/sms.php';$sms_config=file_exists($config_file)?require $config_file:[];
$result_message='';$result_type='success';
if($_SERVER['REQUEST_METHOD']==='POST'){verify_csrf();$message=trim($_POST['message']??'');$audience=$_POST['audience']??'consented';
 if($message===''){$result_message='Enter an SMS message.';$result_type='error';}
 elseif(empty($sms_config['username'])||empty($sms_config['api_key'])){$result_message='SMS gateway is not configured. Copy config/sms.example.php to config/sms.php and add your Africa’s Talking credentials.';$result_type='error';}
 else{
  $where=$audience==='all'?'':' AND sms_consent=1';
  $res=$conn->query("SELECT id,phone FROM customers WHERE phone<>''".$where);
  $recipients=[];while($r=$res->fetch_assoc())$recipients[]=$r;
  if(!$recipients){$result_message='No eligible customers found. Marketing SMS are sent only to customers who have consented.';$result_type='warning';}
  else{
   $numbers=array_map(fn($r)=>$r['phone'],$recipients);
   $payload=['username'=>$sms_config['username'],'to'=>implode(',',$numbers),'message'=>$message];
   if(!empty($sms_config['sender_id']))$payload['from']=$sms_config['sender_id'];
   $ch=curl_init('https://api.africastalking.com/version1/messaging');
   curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>http_build_query($payload),CURLOPT_RETURNTRANSFER=>true,CURLOPT_HTTPHEADER=>['apiKey: '.$sms_config['api_key'],'Accept: application/json','Content-Type: application/x-www-form-urlencoded'],CURLOPT_TIMEOUT=>30]);
   $body=curl_exec($ch);$err=curl_error($ch);$http=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);
   $ok=$body!==false&&$http>=200&&$http<300;
   foreach($recipients as $r){$st=$ok?'Submitted':'Failed';$log=$conn->prepare("INSERT INTO sms_logs(phone,message,status,provider_response,sent_by) VALUES(?,?,?,?,?)");$log->bind_param('ssssi',$r['phone'],$message,$st,$body,(int)$_SESSION['admin_id']);$log->execute();}
   $result_message=$ok?'SMS request submitted to '.$http.' response. Check delivery reports in your Africa’s Talking account.':'SMS request failed: '.($err?:'HTTP '.$http.' '.$body);$result_type=$ok?'success':'error';
  }
 }
}
$total=(int)$conn->query("SELECT COUNT(*) n FROM customers")->fetch_assoc()['n'];$consented=(int)$conn->query("SELECT COUNT(*) n FROM customers WHERE sms_consent=1")->fetch_assoc()['n'];$sent=(int)$conn->query("SELECT COUNT(*) n FROM sms_logs")->fetch_assoc()['n'];
$logs=$conn->query("SELECT * FROM sms_logs ORDER BY id DESC LIMIT 15");$page_title='Bulk SMS';$admin_nav=true;require '../includes/header.php';
?>
<div class="admin-title"><div><h1>Bulk SMS</h1><p class="muted">Send updates and promotions to your customer list.</p></div></div>
<div class="stats"><div class="card stat"><strong><?=$total?></strong><span>Customers</span></div><div class="card stat"><strong><?=$consented?></strong><span>Marketing opt-ins</span></div><div class="card stat"><strong><?=$sent?></strong><span>SMS log entries</span></div></div>
<?php if($result_message):?><div class="alert <?=e($result_type)?>"><?=e($result_message)?></div><?php endif;?>
<div class="panel section"><h2>Compose message</h2><p class="help">Promotional messages must go only to customers who have opted in. The “all” audience should be used only for necessary service messages where you have an appropriate lawful basis.</p>
<form method="post"><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>"><div class="field"><label>Audience</label><select name="audience"><option value="consented">Marketing opt-ins only</option><option value="all">All customers (service messages only)</option></select></div><br><div class="field"><label>SMS message</label><textarea name="message" maxlength="1500" required placeholder="Type your U-Fresh Water Refill message..."></textarea></div><div class="actions"><button class="btn" data-confirm="Send this SMS to the selected customer group?">Submit bulk SMS</button></div></form></div>
<section class="section"><h2>Recent SMS logs</h2><div class="table-wrap"><table><tr><th>Phone</th><th>Message</th><th>Status</th><th>Date</th></tr><?php while($l=$logs->fetch_assoc()):?><tr><td><?=e($l['phone'])?></td><td><?=e(mb_strimwidth($l['message'],0,75,'…'))?></td><td><?=e($l['status'])?></td><td><?=e($l['created_at'])?></td></tr><?php endwhile;?></table></div></section>
<?php require '../includes/footer.php';?>
