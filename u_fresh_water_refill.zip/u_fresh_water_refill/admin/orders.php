<?php
require_once '../config/database.php';require_once '../includes/functions.php';require_admin();
if($_SERVER['REQUEST_METHOD']==='POST'){verify_csrf();$id=(int)$_POST['id'];$status=$_POST['status']??'New';if(in_array($status,['New','Processing','Completed','Cancelled'],true)){$s=$conn->prepare("UPDATE orders SET status=? WHERE id=?");$s->bind_param('si',$status,$id);$s->execute();flash('success','Order status updated.');}redirect('orders.php');}
$rows=$conn->query("SELECT o.*,c.full_name,c.phone FROM orders o JOIN customers c ON c.id=o.customer_id ORDER BY o.id DESC");$page_title='Orders';$admin_nav=true;require '../includes/header.php';
?>
<div class="admin-title"><div><h1>Customer orders</h1><p class="muted">Review orders and update their status.</p></div></div>
<div class="table-wrap"><table><tr><th>Order</th><th>Customer</th><th>Phone</th><th>Total</th><th>Type</th><th>Status</th><th>Date</th></tr><?php while($o=$rows->fetch_assoc()):?><tr><td>#<?=$o['id']?></td><td><?=e($o['full_name'])?></td><td><?=e($o['phone'])?></td><td><?=money($o['total'])?></td><td><?=e($o['delivery_type'])?></td><td><form method="post"><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>"><input type="hidden" name="id" value="<?=$o['id']?>"><select name="status" onchange="this.form.submit()"><?php foreach(['New','Processing','Completed','Cancelled'] as $st):?><option <?=$o['status']===$st?'selected':''?>><?=$st?></option><?php endforeach;?></select></form></td><td><?=e($o['created_at'])?></td></tr><?php endwhile;?></table></div>
<?php require '../includes/footer.php';?>
