</main>
<footer class="footer"><strong>U-Fresh Water Refill</strong><span>Fresh water. Convenient service.</span><small>© <?= date('Y') ?> U-Fresh Water Refill</small></footer>
</body></html>
