<?php
require_once __DIR__.'/functions.php';
$page_title = $page_title ?? 'U-Fresh Water Refill';
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($page_title) ?> | U-Fresh Water Refill</title>
<link rel="stylesheet" href="<?= e($asset_prefix ?? '') ?>assets/css/style.css">
<script defer src="<?= e($asset_prefix ?? '') ?>assets/js/app.js"></script>
</head><body>
<header class="topbar">
  <a class="brand" href="<?= e($home_link ?? 'index.php') ?>"><span class="brand-icon">💧</span><span>U-FRESH <small>WATER REFILL</small></span></a>
  <button class="menu-toggle" type="button" aria-label="Toggle navigation">☰</button>
  <nav class="nav-links">
    <?php if (!empty($admin_nav)): ?>
      <a href="dashboard.php">Dashboard</a><a href="products.php">Products</a><a href="orders.php">Orders</a><a href="customers.php">Customers</a><a href="sms.php">Bulk SMS</a><a href="reports.php">Reports</a><a href="logout.php">Logout</a>
    <?php else: ?>
      <a href="index.php">Home</a><a href="index.php#products">Products & Prices</a><a href="order.php">Order Water</a><a href="index.php#contact">Contact</a><a class="nav-admin" href="admin/login.php">Admin</a>
    <?php endif; ?>
  </nav>
</header>
<main class="container">
<?php show_flash(); ?>
