<?php
declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) session_start();

function e($value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}
function redirect(string $url): never {
    header("Location: $url");
    exit;
}
function is_logged_in(): bool {
    return !empty($_SESSION['admin_id']);
}
function require_admin(): void {
    if (!is_logged_in()) redirect('login.php');
}
function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf_token'];
}
function verify_csrf(): void {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $token = $_POST['csrf_token'] ?? '';
        if (!hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
            http_response_code(403); exit('Invalid security token. Please go back and try again.');
        }
    }
}
function flash(string $type, string $message): void {
    $_SESSION['flash'] = ['type'=>$type, 'message'=>$message];
}
function show_flash(): void {
    if (!empty($_SESSION['flash'])) {
        $f = $_SESSION['flash']; unset($_SESSION['flash']);
        echo '<div class="alert '.e($f['type']).'">'.e($f['message']).'</div>';
    }
}
function money($amount): string {
    return 'KSh '.number_format((float)$amount, 2);
}
function valid_phone(string $phone): bool {
    $digits = preg_replace('/\D+/', '', $phone);
    return strlen($digits) >= 9 && strlen($digits) <= 15;
}
