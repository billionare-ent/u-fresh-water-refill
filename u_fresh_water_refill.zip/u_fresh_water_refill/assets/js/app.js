document.addEventListener('DOMContentLoaded',()=>{
 const toggle=document.querySelector('.menu-toggle'), nav=document.querySelector('.nav-links');
 if(toggle&&nav) toggle.addEventListener('click',()=>nav.classList.toggle('open'));
 document.querySelectorAll('[data-confirm]').forEach(el=>el.addEventListener('click',e=>{
   if(!confirm(el.dataset.confirm||'Are you sure?')) e.preventDefault();
 }));
 document.querySelectorAll('[data-price-qty]').forEach(el=>{
   const update=()=>{const q=Number(document.querySelector('#quantity')?.value||1);const p=Number(el.dataset.priceQty);const out=document.querySelector('#order-total');if(out)out.textContent='KSh '+(q*p).toFixed(2)};
   document.querySelector('#quantity')?.addEventListener('input',update);update();
 });
});
