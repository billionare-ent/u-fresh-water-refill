<?php
require_once 'config/database.php';require_once 'includes/functions.php';
$products=$conn->query("SELECT * FROM products WHERE active=1 ORDER BY id DESC");
$page_title='Home';require 'includes/header.php';
?>
<section class="hero"><div><span class="tag">CLEAN • FRESH • CONVENIENT</span><h1>Fresh drinking water, made easy.</h1><p>Welcome to U-Fresh Water Refill. Get quality drinking water by the litre or in convenient bottle sizes.</p><a class="btn secondary" href="order.php">Place an order</a></div><div class="hero-art">💧</div></section>
<section class="section" id="products"><div class="section-head"><div><h2>Our products & prices</h2><p class="muted">Current prices are updated by our administrator.</p></div><a href="order.php">Order now →</a></div>
<div class="grid"><?php while($p=$products->fetch_assoc()):?><article class="card"><div class="product-icon">💧</div><span class="tag"><?=e(ucfirst($p['unit']))?></span><h3><?=e($p['name'])?></h3><p class="muted"><?=e($p['description'])?></p><div class="price"><?=money($p['price'])?><?php if($p['unit']==='litre'):?><small>/litre</small><?php endif;?></div><a class="btn" href="order.php?product=<?= (int)$p['id']?>">Order this</a></article><?php endwhile;?></div>
</section>
<section class="section panel" id="contact"><h2>Need water?</h2><p>Place an order online or contact U-Fresh Water Refill directly.</p><a class="btn" href="order.php">Order water</a><p class="help">Add your business phone number, location and WhatsApp details in the contact section before publishing.</p></section>
<?php require 'includes/footer.php';?>
