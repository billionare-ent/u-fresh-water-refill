CREATE DATABASE IF NOT EXISTS u_fresh_water_refill CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE u_fresh_water_refill;

CREATE TABLE IF NOT EXISTS admins (
 id INT AUTO_INCREMENT PRIMARY KEY,
 full_name VARCHAR(120) NOT NULL,
 username VARCHAR(60) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 role ENUM('admin','staff') NOT NULL DEFAULT 'admin',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS products (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(140) NOT NULL,
 description TEXT NULL,
 unit VARCHAR(30) NOT NULL DEFAULT 'bottle',
 price DECIMAL(10,2) NOT NULL,
 image VARCHAR(255) NULL,
 active TINYINT(1) NOT NULL DEFAULT 1,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS customers (
 id INT AUTO_INCREMENT PRIMARY KEY,
 full_name VARCHAR(120) NOT NULL,
 phone VARCHAR(25) NOT NULL,
 email VARCHAR(150) NULL,
 address VARCHAR(255) NULL,
 sms_consent TINYINT(1) NOT NULL DEFAULT 0,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY unique_customer_phone(phone)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS orders (
 id INT AUTO_INCREMENT PRIMARY KEY,
 customer_id INT NOT NULL,
 status ENUM('New','Processing','Completed','Cancelled') NOT NULL DEFAULT 'New',
 delivery_type ENUM('Pickup','Delivery') NOT NULL DEFAULT 'Pickup',
 delivery_address VARCHAR(255) NULL,
 notes TEXT NULL,
 total DECIMAL(10,2) NOT NULL DEFAULT 0,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(customer_id) REFERENCES customers(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS order_items (
 id INT AUTO_INCREMENT PRIMARY KEY,
 order_id INT NOT NULL,
 product_id INT NULL,
 product_name VARCHAR(140) NOT NULL,
 quantity INT NOT NULL,
 unit_price DECIMAL(10,2) NOT NULL,
 line_total DECIMAL(10,2) NOT NULL,
 FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE,
 FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS payments (
 id INT AUTO_INCREMENT PRIMARY KEY,
 order_id INT NOT NULL,
 amount DECIMAL(10,2) NOT NULL,
 method ENUM('Cash','M-Pesa','Bank','Other') NOT NULL DEFAULT 'Cash',
 reference VARCHAR(100) NULL,
 paid_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(order_id) REFERENCES orders(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS sms_logs (
 id INT AUTO_INCREMENT PRIMARY KEY,
 phone VARCHAR(25) NOT NULL,
 message TEXT NOT NULL,
 status VARCHAR(40) NOT NULL,
 provider_response TEXT NULL,
 sent_by INT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(sent_by) REFERENCES admins(id) ON DELETE SET NULL
) ENGINE=InnoDB;

INSERT INTO products(name,description,unit,price,active)
SELECT 'Water refill per litre','Fresh drinking water refill','litre',10,1
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name='Water refill per litre');
INSERT INTO products(name,description,unit,price,active)
SELECT '20-litre water bottle','20-litre water bottle refill / product','bottle',300,1
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name='20-litre water bottle');
INSERT INTO products(name,description,unit,price,active)
SELECT '10-litre water bottle','10-litre water bottle refill / product','bottle',170,1
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name='10-litre water bottle');
INSERT INTO products(name,description,unit,price,active)
SELECT '5-litre water bottle','5-litre water bottle refill / product','bottle',80,1
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name='5-litre water bottle');

-- Create the first admin from the setup page, then delete/disable setup_admin.php.
